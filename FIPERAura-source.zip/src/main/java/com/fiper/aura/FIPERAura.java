package com.fiper.aura;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class FIPERAura extends JavaPlugin implements Listener {
    private YamlConfiguration data;
    private File dataFile;
    private NamespacedKey shopKey;
    private final Map<String, Long> lastKills = new HashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try { getDataFolder().mkdirs(); dataFile.createNewFile(); }
            catch (IOException e) { getLogger().severe("Could not create data.yml: " + e.getMessage()); }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
        shopKey = new NamespacedKey(this, "aura_spawner_type");
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("FIPERAura enabled. Aura is stored separately from Vault.");
    }

    @Override public void onDisable() { saveData(); }

    private void saveData() {
        try { data.save(dataFile); }
        catch (IOException e) { getLogger().severe("Could not save Aura balances: " + e.getMessage()); }
    }

    private String path(UUID uuid) { return "balances." + uuid; }
    private long balance(UUID uuid) { return data.getLong(path(uuid), 0L); }
    private void setBalance(UUID uuid, long amount) { data.set(path(uuid), Math.max(0L, amount)); saveData(); }
    private void addAura(UUID uuid, long amount) { setBalance(uuid, balance(uuid) + amount); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        Entity victim = event.getEntity();
        Player killer = victim instanceof Player p ? p.getKiller() : null;
        if (killer == null || killer.getUniqueId().equals(victim.getUniqueId())) return;
        long now = System.currentTimeMillis();
        String key = killer.getUniqueId() + ":" + victim.getUniqueId();
        long cooldown = Math.max(0, getConfig().getLong("anti-farm-minutes", 10)) * 60_000L;
        Long previous = lastKills.get(key);
        if (previous != null && now - previous < cooldown) {
            killer.sendMessage("§cلم تحصل على Aura لأن قتل نفس اللاعب متكرر.");
            return;
        }
        lastKills.put(key, now);
        long reward = Math.max(0, getConfig().getLong("kill-reward", 10));
        addAura(killer.getUniqueId(), reward);
        killer.sendMessage("§d✦ +" + reward + " Aura §7| رصيدك: §f" + balance(killer.getUniqueId()));
        killer.playSound(killer.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.4f);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command is for players.");
            return true;
        }
        if (label.equalsIgnoreCase("aurashop") || (args.length > 0 && args[0].equalsIgnoreCase("shop"))) {
            openShop(player);
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("balance")) {
            player.sendMessage("§d✦ رصيد Aura: §f" + balance(player.getUniqueId()));
            return true;
        }
        if (args[0].equalsIgnoreCase("shop")) { openShop(player); return true; }
        if (args[0].equalsIgnoreCase("pay") && args.length == 3 && player.hasPermission("fiperaura.admin")) {
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            long amount;
            try { amount = Long.parseLong(args[2]); } catch (NumberFormatException ex) { player.sendMessage("§cمبلغ غير صحيح."); return true; }
            if (amount < 1) { player.sendMessage("§cالمبلغ لازم يكون موجب."); return true; }
            addAura(target.getUniqueId(), amount);
            player.sendMessage("§aتمت إضافة " + amount + " Aura إلى " + args[1]);
            return true;
        }
        player.sendMessage("§7استخدم §d/aura §7أو §d/aura shop");
        return true;
    }

    private void openShop(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§8Aura §dSpawner Shop");
        for (Map.Entry<String, Object> entry : getConfig().getConfigurationSection("spawner-prices").getValues(false).entrySet()) {
            String type = entry.getKey();
            long price = ((Number) entry.getValue()).longValue();
            Material icon = iconFor(type);
            ItemStack item = new ItemStack(icon);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName("§d" + pretty(type) + " Spawner");
            meta.setLore(java.util.List.of("§7السعر: §d" + price + " Aura", "§eاضغط للشراء"));
            meta.getPersistentDataContainer().set(shopKey, PersistentDataType.STRING, type);
            item.setItemMeta(meta);
            int slot = inv.firstEmpty();
            if (slot >= 0) inv.setItem(slot, item);
        }
        player.openInventory(inv);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onShopClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = event.getView().getTitle();
        if (title.equals("§8Aura §dSpawner Shop")) {
            event.setCancelled(true);
            ItemStack item = event.getCurrentItem();
            if (item == null || !item.hasItemMeta()) return;
            String type = item.getItemMeta().getPersistentDataContainer().get(shopKey, PersistentDataType.STRING);
            if (type == null) return;
            buySpawner(player, type);
            return;
        }

        // Intercept only the DonutShop shard GUI spawner entries; leave all other items alone.
        String configuredTitle = getConfig().getString("shop-title", "ѕʜᴏᴘ - ꜱʜᴀʀᴅ");
        if (!stripColors(title).equalsIgnoreCase(stripColors(configuredTitle))) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() != Material.SPAWNER || !clicked.hasItemMeta()) return;

        String type = inferSpawnerType(clicked);
        if (type == null || !getConfig().contains("spawner-prices." + type)) return;
        // Prevent DonutShop from charging Vault for configured spawner entries.
        event.setCancelled(true);
        buySpawner(player, type);
    }

    private void buySpawner(Player player, String type) {
        long price = getConfig().getLong("spawner-prices." + type, -1);
        if (price < 0) { player.sendMessage("§cهذا السبونر غير مفعّل بمتجر Aura."); return; }
        long current = balance(player.getUniqueId());
        if (current < price) {
            player.sendMessage("§cرصيدك ما يكفي. تحتاج " + price + " Aura.");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1f);
            return;
        }
        // Charge first; if the delivery command fails, refund immediately.
        setBalance(player.getUniqueId(), current - price);
        String cmd = getConfig().getString("smartspawner-command", "ss give %player% %type% 1")
                .replace("%player%", player.getName()).replace("%type%", type.toUpperCase(Locale.ROOT));
        boolean dispatched = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        if (!dispatched) {
            addAura(player.getUniqueId(), price);
            player.sendMessage("§cفشل تسليم السبونر؛ تم إرجاع Aura إلى رصيدك.");
            return;
        }
        player.sendMessage("§aتم شراء §d" + pretty(type) + " Spawner §aبسعر §d" + price + " Aura§a.");
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
    }

    private String inferSpawnerType(ItemStack item) {
        String name = item.getItemMeta().hasDisplayName() ? item.getItemMeta().getDisplayName() : "";
        String text = stripColors(name).toLowerCase(Locale.ROOT).replace(" spawner", "").replace(" mob", "").trim();
        text = text.replace(' ', '_').replace('-', '_');
        Map<String, String> aliases = Map.of(
            "pig", "pig", "cow", "cow", "zombie", "zombie", "spider", "spider",
            "skeleton", "skeleton", "creeper", "creeper", "blaze", "blaze",
            "iron_golem", "iron_golem", "iron golem", "iron_golem",
            "zombified_piglin", "zombified_piglin", "zombie_pigman", "zombified_piglin"
        );
        return aliases.get(text);
    }

    private Material iconFor(String type) {
        return switch (type.toLowerCase(Locale.ROOT)) {
            case "pig" -> Material.PIG_SPAWN_EGG;
            case "cow" -> Material.COW_SPAWN_EGG;
            case "zombie" -> Material.ZOMBIE_SPAWN_EGG;
            case "spider" -> Material.SPIDER_SPAWN_EGG;
            case "skeleton" -> Material.SKELETON_SPAWN_EGG;
            case "creeper" -> Material.CREEPER_SPAWN_EGG;
            case "blaze" -> Material.BLAZE_SPAWN_EGG;
            case "iron_golem" -> Material.IRON_GOLEM_SPAWN_EGG;
            default -> Material.ZOMBIFIED_PIGLIN_SPAWN_EGG;
        };
    }

    private String pretty(String type) {
        String[] parts = type.split("_");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (out.length() > 0) out.append(' ');
            out.append(part.substring(0, 1).toUpperCase(Locale.ROOT)).append(part.substring(1));
        }
        return out.toString();
    }

    private String stripColors(String text) { return text == null ? "" : text.replaceAll("§[0-9A-FK-ORa-fk-or]", ""); }
}
